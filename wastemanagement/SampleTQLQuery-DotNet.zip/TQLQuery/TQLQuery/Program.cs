﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace TQLQuery
{
    class Program
    {
        static void Main(string[] args)
        {
            WebRequest req = WebRequest.Create("http://54.175.160.37:8080/fid-TqlInterface");
            
            req.Method = "POST";
            using (Stream reqStream = req.GetRequestStream())
            {
                byte[] reqData = UTF8Encoding.UTF8.GetBytes("<Query>" +
                                                                "<Find>" +
                                                                    "<Resident>" +
                                                                        "<Id Ne=\"\"/>" +
                                                                    "</Resident>" +
                                                                "</Find>" +
                                                            "</Query>");
                reqStream.Write(reqData, 0, reqData.Length);
            }
            using(WebResponse resp = req.GetResponse())
            {
                using(Stream respStream = resp.GetResponseStream())
                {
                    XmlDocument doc = new XmlDocument();
                    doc.Load(respStream);
                    XmlNodeList residents = doc.SelectNodes("Find/Result/Resident");
                    foreach(XmlNode resident in residents)
                    {
                        Console.WriteLine("Resident");
                        Console.WriteLine("\tID: " + resident.SelectSingleNode("Id").InnerText);
                        Console.WriteLine("\tLocation:\n\t\tx:" + resident.SelectSingleNode("LocationHome/X").InnerText);
                        Console.WriteLine("\t\ty:" + resident.SelectSingleNode("LocationHome/Y").InnerText);
                        Console.WriteLine("\tPhotosTaken: " + resident.SelectSingleNode("PhotosTaken").InnerText);
                        Console.WriteLine("\tIsInfluencer: " + resident.SelectSingleNode("IsInfluencer").InnerText);
                        Console.WriteLine("\tSmartphoneId: " + resident.SelectSingleNode("SmartphoneId").InnerText);
                    }
                }
            }
            Console.ReadLine();
            
        }
    }
}
